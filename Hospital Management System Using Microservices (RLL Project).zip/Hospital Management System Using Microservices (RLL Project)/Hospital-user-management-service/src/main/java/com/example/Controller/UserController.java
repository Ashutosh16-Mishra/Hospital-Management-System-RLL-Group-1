package com.example.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.Service.UserService;
import com.example.entity.Doctor;
import com.example.entity.Patient;
import com.example.entity.User;
import com.example.externalService.DoctorServiceClient;
import com.example.externalService.PatientServiceClient;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;
    
    @Autowired
    private DoctorServiceClient doctorServiceClient;
    
    @Autowired
    private PatientServiceClient patientServiceClient;

    @PostMapping("/register")
    public User registerUser(@RequestBody User user) {
        return userService.registerUser(user);
    }

    @GetMapping("/pending-approval/{role}")
    public List<User> getPendingApprovalUsers(@PathVariable String role) {
        return userService.getPendingApprovalUsers(role);
    }

    @PostMapping("/approve/{userId}")
    public ResponseEntity<String> approveUser(@PathVariable Long userId) {
        userService.approveUser(userId);
        return ResponseEntity.status(HttpStatus.OK).body("User approved successfully.");
    }

    @GetMapping("/all")
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }
    
    // New endpoint to test the DoctorClient
    @GetMapping("/doctors")
    public ResponseEntity<String> testFeignClient(@RequestParam Long id) {
        // Use the DoctorClient to fetch doctor data
        return doctorServiceClient.getDoctorById(id)
                .map(doctor -> ResponseEntity.ok("Doctor data: " + doctor.toString()))
                .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/patient/{patientId}")
    public Patient checkFeignClient(@PathVariable Long patientId) {
        // Call the Feign client to retrieve patient information
        return patientServiceClient.getPatientById(patientId);
    }
}

