package com.example.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.Repository.UserRepository;
import com.example.entity.Doctor;
import com.example.entity.Patient;
import com.example.entity.User;
import com.example.externalService.DoctorServiceClient;
import com.example.externalService.PatientServiceClient;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private DoctorServiceClient doctorServiceClient;
    
    @Autowired
    private PatientServiceClient patientServiceClient;

    public User registerUser(User user) {
        return userRepository.save(user);
    }

    public List<User> getPendingApprovalUsers(String role) {
        return userRepository.findByRoleAndApproved(role, false);
    }

    public void approveUser(Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        if (user != null) {
            user.setApproved(true);
            userRepository.save(user);
        }
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    
    // Fetch doctor information using the Feign client
    public Optional<Doctor> getDoctorById(Long docterId) {
        return doctorServiceClient.getDoctorById(docterId);
    }
    
    public Patient getPatientById(Long patientId) {
        // Use the Feign client to fetch patient data from the Patient Service
        return patientServiceClient.getPatientById(patientId);
    }
    
}


