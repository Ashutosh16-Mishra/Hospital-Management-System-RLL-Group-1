package com.example.externalservice;

import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.entity.Doctor;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "Doctor-Service")
public interface DoctorClient {

    @Retry(name = "Doctor-Service")
    @CircuitBreaker(name = "Doctor-Service", fallbackMethod = "fallbackMethodGetDoctorById")
    @GetMapping(value = "/doctors/{doctorId}", produces = { MediaType.APPLICATION_JSON_VALUE })
    public Optional<Doctor> getDoctorById(@PathVariable("doctorId") Long doctorId);

    // Add any additional methods for the Doctor service here if needed

    public default Optional<Doctor> fallbackMethodGetDoctorById(Long doctorId, Throwable cause) {
        System.out.println("Exception raised with message: " + cause.getMessage());
        // Create a default Doctor instance or handle the fallback logic as needed
        Doctor defaultDoctor = new Doctor();
        defaultDoctor.setDocterId(doctorId);
        defaultDoctor.setName("Default Name");
        defaultDoctor.setSpecialization("Default Specialization");
        defaultDoctor.setApproved(false);

        return Optional.of(defaultDoctor);
    }
}