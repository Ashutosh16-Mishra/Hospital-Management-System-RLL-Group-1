package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.externalservice.AppointmentFeignClient;
import com.example.externalservice.DoctorClient; // Import DoctorClient
import com.example.entity.Appointment;
import com.example.entity.Doctor; // Import Doctor
import com.example.entity.Patient;
import com.example.repository.PatientRepository;

import java.util.List;
import java.util.Optional;

@Service
public class PatientService {
    @Autowired
    private PatientRepository patientRepository;

    @Autowired
    private DoctorClient doctorClient;
    
    @Autowired
    private AppointmentFeignClient appointmentFeignClient;

    public Patient registerPatient(Patient patient) {
        return patientRepository.save(patient);
    }

    public List<Patient> getPendingApprovalPatients() {
        return patientRepository.findByApproved(false);
    }

    public void approvePatient(Long patientId) {
        Patient patient = patientRepository.findById(patientId).orElse(null);
        if (patient != null) {
            patient.setApproved(true);
            patientRepository.save(patient);
        }
    }

    public void rejectPatient(Long patientId) {
        patientRepository.deleteById(patientId);
    }

    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    public void bookAppointment(Long patientId, Long doctorId) {
        // Implement appointment booking logic here, e.g., update the patient's assignedDoctorId
    }

    public List<Patient> getDischargedPatients() {
        return patientRepository.findByDischarged(true);
    }

    // Fetch doctor information using the Feign client
    public Optional<Doctor> getDoctorById(Long docterId) {
        return doctorClient.getDoctorById(docterId);
    }
    
    public Optional<Patient> getPatientById(Long patientId) {
        return patientRepository.findById(patientId);
    }
    
    public Appointment getAppointmentById(Long appointmentId) {
        return appointmentFeignClient.getAppointmentById(appointmentId);
    }
}

