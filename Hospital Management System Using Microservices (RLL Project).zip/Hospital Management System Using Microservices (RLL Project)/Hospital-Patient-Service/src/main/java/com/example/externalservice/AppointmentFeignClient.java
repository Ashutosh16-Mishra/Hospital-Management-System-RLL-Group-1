package com.example.externalservice;



import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.entity.Appointment;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "Appointment-Service")
public interface AppointmentFeignClient {

    @Retry(name = "Appointment-Service")
    @CircuitBreaker(name = "Appointment-Service", fallbackMethod = "fallbackMethodGetAppointmentById")
    @GetMapping(value = "/appointments/{appointmentId}", produces = { MediaType.APPLICATION_JSON_VALUE })
    Appointment getAppointmentById(@PathVariable("appointmentId") Long appointmentId);

    // Add any additional methods for the Appointment service here if needed

    default Appointment fallbackMethodGetAppointmentById(Long appointmentId, Throwable cause) {
        System.out.println("Exception raised with message: " + cause.getMessage());
        // Create a default Appointment object or handle the fallback logic as needed
        Appointment defaultAppointment = new Appointment();
        defaultAppointment.setAppointmentId(appointmentId);
        defaultAppointment.setPatientId(null);
        defaultAppointment.setDoctorId(null);
        defaultAppointment.setApproved(false);

        return defaultAppointment;
    }
}
